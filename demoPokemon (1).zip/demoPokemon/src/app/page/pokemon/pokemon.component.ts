import { Component, OnInit } from '@angular/core';
import { PokemonService } from 'src/app/service/pokemon.service';

@Component({
  selector: 'app-pokemon',
  templateUrl: './pokemon.component.html',
  styleUrls: ['./pokemon.component.css']
})
export class PokemonComponent implements OnInit {
  nombre: string = "";
  foto: string = "";
  constructor(private pS: PokemonService) { }

  ngOnInit(): void {
  }
  buscar() {
    this.pS.buscarPokemon(this.nombre).subscribe(data => {
      this.foto = data.sprites.front_shiny;
    })
  }

}
